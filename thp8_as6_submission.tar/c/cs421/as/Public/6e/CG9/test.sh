./compile.sh $1 && gcc -m32 runtime.c $1.s && ./a.out
